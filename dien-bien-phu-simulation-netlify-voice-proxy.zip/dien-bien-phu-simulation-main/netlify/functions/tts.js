// Netlify Function: Vietnamese TTS proxy
// The browser cannot reliably call Google Translate TTS directly because
// extensions/security policies may block the request. The server function
// fetches the audio instead and returns it to the browser.

exports.handler = async (event) => {
  try {
    const text = (event.queryStringParameters && event.queryStringParameters.text || '').trim();
    if (!text) {
      return { statusCode: 400, headers: { 'Content-Type': 'text/plain; charset=utf-8' }, body: 'Missing text' };
    }

    // Keep requests reasonably small and avoid abusing the endpoint.
    const q = text.slice(0, 450);
    const url = 'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=vi-VN&q=' + encodeURIComponent(q);

    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/154 Safari/537.36',
        'Accept': 'audio/mpeg,audio/*;q=0.9,*/*;q=0.8'
      }
    });

    if (!response.ok) {
      return {
        statusCode: 502,
        headers: { 'Content-Type': 'text/plain; charset=utf-8' },
        body: `TTS upstream error: ${response.status}`
      };
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    return {
      statusCode: 200,
      isBase64Encoded: true,
      headers: {
        'Content-Type': 'audio/mpeg',
        'Cache-Control': 'public, max-age=86400'
      },
      body: buffer.toString('base64')
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: 'TTS proxy failed'
    };
  }
};
