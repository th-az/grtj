/**
 * NARRATOR - Vietnamese narration
 * Primary: Netlify server-side TTS proxy (works even when Chrome has no
 * Vietnamese SpeechSynthesis voice). Fallback: browser SpeechSynthesis.
 */

const Narrator = {
  isActive: false,
  currentPhase: -1,
  sentenceIndex: 0,
  timer: null,
  currentAudio: null,
  usingWebSpeech: false,
  selectedVoice: null,
  voiceReady: false,

  stopAudio() {
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
        this.currentAudio.removeAttribute('src');
        this.currentAudio.load();
      } catch (e) {}
      this.currentAudio = null;
    }
  },

  getVietnameseVoices() {
    if (!window.speechSynthesis) return [];
    return speechSynthesis.getVoices().filter(v => /^vi(?:-|$)/i.test(v.lang || ''));
  },

  chooseVietnameseVoice() {
    const voices = this.getVietnameseVoices();
    if (!voices.length) return null;
    const preferred = [
      /hoai\s*my/i, /hoaimy/i, /linh/i,
      /google.*vietnam/i, /vietnamese.*google/i,
      /female/i, /nữ/i
    ];
    for (const pattern of preferred) {
      const found = voices.find(v => pattern.test(v.name || ''));
      if (found) return found;
    }
    const microsoft = voices.find(v => /microsoft/i.test(v.name || ''));
    return microsoft || voices[0];
  },

  refreshVoices() {
    this.selectedVoice = this.chooseVietnameseVoice();
    this.voiceReady = !!this.selectedVoice;
    const status = document.getElementById('voice-status');
    if (status && this.selectedVoice) {
      status.textContent = `🇻🇳 ${this.selectedVoice.name}`;
      status.classList.remove('voice-error');
    }
    return this.selectedVoice;
  },

  setStatus(text, error = false) {
    const status = document.getElementById('voice-status');
    if (status) {
      status.textContent = text;
      status.classList.toggle('voice-error', !!error);
    }
  },

  // Main path: audio comes from our Netlify Function, so the browser does
  // not contact Google Translate directly.
  speakWithServerTTS(text, onDone, onError) {
    this.stopAudio();
    const audio = new Audio();
    const url = '/.netlify/functions/tts?text=' + encodeURIComponent(text);
    this.currentAudio = audio;
    audio.preload = 'auto';
    audio.volume = 1;

    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      this.currentAudio = null;
      onDone && onDone();
    };
    const fail = () => {
      if (finished) return;
      finished = true;
      this.currentAudio = null;
      onError && onError();
    };

    audio.onplay = () => this.setStatus('🔊 Đang phát giọng kể tiếng Việt');
    audio.onended = done;
    audio.onerror = fail;
    audio.src = url;

    const p = audio.play();
    if (p && typeof p.catch === 'function') p.catch(fail);
  },

  speakWithBrowserVoice(text, onDone, onError) {
    if (!window.speechSynthesis || typeof SpeechSynthesisUtterance === 'undefined') {
      onError && onError('Trình duyệt không hỗ trợ đọc văn bản.');
      return;
    }

    const voice = this.refreshVoices();
    if (!voice) {
      onError && onError('Không tìm thấy giọng Việt của trình duyệt.');
      return;
    }

    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = voice;
    utterance.lang = voice.lang || 'vi-VN';
    utterance.rate = CONFIG.NARRATOR_RATE;
    utterance.pitch = CONFIG.NARRATOR_PITCH;
    utterance.volume = 1;
    this.usingWebSpeech = true;
    let ended = false;

    utterance.onstart = () => this.setStatus(`🔊 ${voice.name}`);
    utterance.onend = () => {
      if (ended) return;
      ended = true;
      this.usingWebSpeech = false;
      onDone && onDone();
    };
    utterance.onerror = (event) => {
      if (ended) return;
      ended = true;
      this.usingWebSpeech = false;
      onError && onError(`Không phát được giọng: ${event.error || 'unknown'}`);
    };
    speechSynthesis.speak(utterance);
  },

  speakVietnamese(text, onDone, onError) {
    // Use the server TTS first. This is independent of Windows voice packs.
    this.speakWithServerTTS(text, onDone, () => {
      // Fallback for local/offline development.
      this.speakWithBrowserVoice(text, onDone, onError);
    });
  },

  start(phase) {
    this.stop();
    if (!this.isActive) return;
    this.currentPhase = phase;
    const data = NARRATIONS[phase];
    if (!data) return;
    this.sentenceIndex = 0;
    const narrator = document.getElementById('narrator');
    if (narrator) narrator.style.display = 'block';
    document.getElementById('narrator-phase').textContent = data.phase;
    this.speakSentence(phase, 0);
  },

  stop() {
    if (window.speechSynthesis) speechSynthesis.cancel();
    this.usingWebSpeech = false;
    this.stopAudio();
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    const narrator = document.getElementById('narrator');
    if (narrator) narrator.style.display = 'none';
    this.sentenceIndex = 0;
    this.currentPhase = -1;
    const bar = document.getElementById('narrator-bar');
    if (bar) bar.style.width = '0%';
  },

  testVoice() {
    const text = 'Xin chào. Đây là giọng kể tiếng Việt của sa bàn Chiến dịch Điện Biên Phủ.';
    const oldActive = this.isActive;
    this.speakVietnamese(
      text,
      () => {
        this.isActive = oldActive;
        this.setStatus('✓ Giọng kể tiếng Việt hoạt động');
      },
      (msg) => {
        this.setStatus('❌ ' + (msg || 'Không phát được giọng tiếng Việt.'), true);
      }
    );
  },

  speakSentence(phase, index) {
    if (!this.isActive || this.currentPhase !== phase) return;
    const data = NARRATIONS[phase];
    if (!data || index >= data.sentences.length) {
      this.stop();
      return;
    }

    const total = data.sentences.length;
    const percent = Math.round((index / total) * 100);
    const bar = document.getElementById('narrator-bar');
    if (bar) bar.style.width = percent + '%';

    const text = data.sentences[index];
    let html = text;
    NARRATOR_KEYWORDS.forEach(keyword => {
      html = html.replaceAll(keyword, `<span class="highlight">${keyword}</span>`);
    });
    const textEl = document.getElementById('narrator-text');
    if (textEl) textEl.innerHTML = html;

    const next = () => {
      if (!this.isActive || this.currentPhase !== phase) return;
      this.timer = setTimeout(() => this.speakSentence(phase, index + 1), CONFIG.NARRATOR_PAUSE);
    };

    const failed = (msg) => {
      const el = document.getElementById('narrator-text');
      if (el) el.innerHTML = `<span class="highlight">Không phát được giọng tiếng Việt.</span><br>${msg || 'Hãy kiểm tra kết nối Internet.'}`;
      this.isActive = false;
      const btn = document.getElementById('btn-narrate');
      if (btn) {
        btn.textContent = '🎙 Giọng kể chuyện';
        btn.classList.remove('narr-active');
      }
    };

    this.speakVietnamese(text, next, failed);

    AudioEngine.init();
    if (index === 0 && (phase === 1 || phase === 2 || phase === 3)) {
      setTimeout(() => { AudioEngine.playCannon(0.6); AudioEngine.playGunfire(5, 100); }, 500);
    }
    if (phase === 3 && index === 1) {
      setTimeout(() => { AudioEngine.playExplosion(0.8); ParticleSystem.triggerExplosions(5); }, 800);
    }
    if (phase === 3 && index === 3) {
      setTimeout(() => { AudioEngine.playVictory(); }, 1200);
    }
  },

  toggle() {
    this.isActive = !this.isActive;
    return this.isActive;
  }
};

if (window.speechSynthesis) {
  speechSynthesis.addEventListener('voiceschanged', () => Narrator.refreshVoices());
  setTimeout(() => Narrator.refreshVoices(), 300);
}
